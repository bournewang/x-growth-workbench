globalThis.XPCLicenseConfig = Object.freeze({ apiBaseUrl: "https://x-growth-license.xiaopei0206.workers.dev", required: true, trialDays: 3, serverTrial: true, reportingRequired: true });
